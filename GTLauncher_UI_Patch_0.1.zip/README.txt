GT Launcher UI Patch 0.1

Replace the two fragment_launcher.xml files in the matching res/layout and res/layout-land folders. Existing IDs are preserved, so MainMenuFragment keeps the real PLAY launch path. This patch changes UI only; GT MAX FPS wiring comes next.
